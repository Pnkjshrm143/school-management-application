<?php
$conn = new mysqli('localhost', 'root', '', 'school_db');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_GET['id'];

// Fetch the student's image filename to delete the file
$sql = "SELECT image FROM student WHERE id = $id";
$result = $conn->query($sql);
$student = $result->fetch_assoc();

// Delete the student record
$sql = "DELETE FROM student WHERE id = $id";
if ($conn->query($sql) === TRUE) {
    // Delete the image file
    if (file_exists("uploads/" . $student['image'])) {
        unlink("uploads/" . $student['image']);
    }
    header("Location: index.php");
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>
