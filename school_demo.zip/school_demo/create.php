<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "school_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $class_id = $_POST['class_id'];

    $image = "";
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['image']['tmp_name'];
        $file_name = basename($_FILES['image']['name']);
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $allowed_ext = array('jpg', 'jpeg', 'png');

        if (in_array($file_ext, $allowed_ext)) {
            $image = uniqid() . "." . $file_ext;
            $upload_dir = 'uploads/';
            $upload_file = $upload_dir . $image;

            if (move_uploaded_file($file_tmp, $upload_file)) {
                // File uploaded successfully
            } else {
                echo "Error moving uploaded file.";
                exit;
            }
        } else {
            echo "Invalid file format. Only jpg and png are allowed.";
            exit;
        }
    } elseif ($_FILES['image']['error'] != UPLOAD_ERR_NO_FILE) {
        // Handle other upload errors
        echo "Upload error: " . $_FILES['image']['error'];
        exit;
    }

    // Insert into database
    $stmt = $conn->prepare("INSERT INTO student (name, email, address, class_id, image) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssis", $name, $email, $address, $class_id, $image);

    if ($stmt->execute()) {
        header("Location: index.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Student</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Create Student</h1>
        <form action="create.php" method="post" enctype="multipart/form-data">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
            
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            
            <label for="address">Address:</label>
            <textarea id="address" name="address"></textarea>
            
            <label for="class_id">Class:</label>
            <select id="class_id" name="class_id">
                <?php
                // Fetch classes for dropdown
                $conn = new mysqli($servername, $username, $password, $database);
                $result = $conn->query("SELECT class_id, name FROM classes");
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='{$row['class_id']}'>{$row['name']}</option>";
                }
                $conn->close();
                ?>
            </select>
            
            <label for="image">Image:</label>
            <input type="file" id="image" name="image">
            
            <button type="submit">Create</button>
        </form>
    </div>
</body>
</html>
