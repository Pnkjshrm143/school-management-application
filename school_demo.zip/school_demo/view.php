<?php
$conn = new mysqli('localhost', 'root', '', 'school_db');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_GET['id'];
$sql = "SELECT student.*, classes.name AS class_name 
        FROM student 
        LEFT JOIN classes ON student.class_id = classes.class_id 
        WHERE student.id = $id";
$result = $conn->query($sql);
$student = $result->fetch_assoc();

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Student</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h1 class="mt-4">View Student</h1>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><?= htmlspecialchars($student['name']) ?></h5>
            <p class="card-text">Email: <?= htmlspecialchars($student['email']) ?></p>
            <p class="card-text">Address: <?= htmlspecialchars($student['address']) ?></p>
            <p class="card-text">Class: <?= htmlspecialchars($student['class_name']) ?></p>
            <p class="card-text">Created At: <?= htmlspecialchars($student['created_at']) ?></p>
            <img src="uploads/<?= htmlspecialchars($student['image']) ?>" alt="Student Image" class="img-thumbnail">
        </div>
    </div>
    <a href="index.php" class="btn btn-secondary mt-3">Back to List</a>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
