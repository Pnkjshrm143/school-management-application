<?php
$conn = new mysqli('localhost', 'root', '', 'school_db');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_GET['id'];

// Fetch student data
$sql = "SELECT * FROM student WHERE id = $id";
$result = $conn->query($sql);
$student = $result->fetch_assoc();

// Fetch classes for dropdown
$class_sql = "SELECT * FROM classes";
$class_result = $conn->query($class_sql);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $class_id = $_POST['class_id'];
    $image = $_FILES['image']['name'];

    // Image upload handling
    if ($image) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($image);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Validate image
        $valid_extensions = array("jpg", "jpeg", "png");
        if (!in_array($imageFileType, $valid_extensions)) {
            echo "Sorry, only JPG, JPEG, and PNG files are allowed.";
            $image = $student['image']; // Keep the old image if the new one is invalid
        } else {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                if (file_exists("uploads/" . $student['image'])) {
                    unlink("uploads/" . $student['image']); // Remove the old image
                }
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        }
    } else {
        $image = $student['image']; // Keep the old image if no new image is uploaded
    }

    // Update student data
    $sql = "UPDATE student SET name='$name', email='$email', address='$address', class_id='$class_id', image='$image' WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Student</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h1 class="mt-4">Edit Student</h1>
    <form action="edit.php?id=<?= $id ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($student['name']) ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($student['email']) ?>" required>
        </div>
        <div class="form-group">
            <label for="address">Address</label>
            <textarea class="form-control" id="address" name="address" rows="3"><?= htmlspecialchars($student['address']) ?></textarea>
        </div>
        <div class="form-group">
            <label for="class">Class</label>
            <select class="form-control" id="class" name="class_id" required>
                <?php while($row = $class_result->fetch_assoc()): ?>
                <option value="<?= $row['class_id'] ?>" <?= $row['class_id'] == $student['class_id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($row['name']) ?>
                </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="image">Upload Image</label>
            <input type="file" class="form-control-file" id="image" name="image">
            <small class="form-text text-muted">Current Image: <?= htmlspecialchars($student['image']) ?></small>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
